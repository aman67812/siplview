from django.shortcuts import render
from .models import Latest,Project,Late
from math import ceil
# Create your views here.
def index(request):
    login = 'true'
    aprod = []
    catprod = Late.objects.values('categoty', 'id')
    cats = {item['categoty'] for item in catprod}
    i=1
    for cat in cats:
        prod = Late.objects.filter(categoty=cat)
        n = len(prod)
        nos = n // 4 + ceil((n / 4) - (n // 4))
        aprod.append([prod, range(1, nos), nos])

    ap = []
    catp = Project.objects.values('categoty', 'id')
    ca = {item['categoty'] for item in catp}
    for cati in ca:
        prodi = Project.objects.filter(categoty=cati)
        n1 = len(prodi)
        noso = n1 // 4 + ceil((n1 / 4) - (n1 // 4))
        ap.append([prodi, range(1, noso), noso])

    params = {'allprod': aprod,'allod':ap}
    return render(request,'main\index.html',params)
def contact(request):
    return render(request, 'main\contact.html')
def about(request):
    login = 'true'
    aprod = []
    catprod = Late.objects.values('categoty', 'id')
    cats = {item['categoty'] for item in catprod}
    for cat in cats:
        prod = Late.objects.filter(categoty=cat)
        n = len(prod)
        nos = n // 4 + ceil((n / 4) - (n // 4))
        aprod.append([prod, range(1, nos), nos])
    aprod.reverse()
    params = {'allprod': aprod[:3]}
    return render(request, 'main\\about.html',params)
def course(request):
    login = 'true'
    aprod = []
    catprod = Latest.objects.values('categoty', 'id')
    cats = {item['categoty'] for item in catprod}
    for cat in cats:
        prod = Latest.objects.filter(categoty=cat)
        n = len(prod)
        nos = n // 4 + ceil((n / 4) - (n // 4))
        aprod.append([prod, range(1, nos), nos])
    params = {'allprod': aprod}
    return render(request, 'main\course.html',params)

def searchMatch(query,item):
   if query in item.product_Name.lower() or query in item.categoty.lower() or query in item.sub_categoty.lower():
      return True
   else:
      return False

def search(request,m):
   query=m
   aprod = []
   catprod = Latest.objects.values('categoty', 'id')
   cats = {item['categoty'] for item in catprod}
   for cat in cats:
      prodtemp = Latest.objects.filter(categoty=cat)
      prod=[i for i in prodtemp if searchMatch(query,i)]
      n = len(prod)
      nos = n // 4 + ceil((n / 4) - (n // 4))
      if len(prod) != 0:
       aprod.append([prod, range(1, nos), nos])
   params = {'allprod': aprod,"msg":""}
   if len(aprod)==0 or len(query)<4:
         params={"msg":"Sorry, No item,we can add item in future"}
   return render(request, 'main\course.html', params)
def searchu(request):
 if request.method=="POST":
   query=request.POST.get('search')
   query=query.lower()
   hj="minimal"
   print(query,hj)
   aprod = []
   catprod =Latest.objects.values('categoty', 'id')
   cats = {item['categoty'] for item in catprod}
   for cat in cats:
      prodtemp = Latest.objects.filter(categoty=cat)
      prod=[i for i in prodtemp if searchMatch(query,i)]
      n = len(prod)
      nos = n // 4 + ceil((n / 4) - (n // 4))
      if len(prod) != 0:
       aprod.append([prod, range(1, nos), nos])
   params = {'allprod': aprod,"msg":""}
   if len(aprod)==0 or len(query)<4:
         params={"msg":"Sorry, No item,we can add item in future"}
   return render(request, 'main\course.html', params)